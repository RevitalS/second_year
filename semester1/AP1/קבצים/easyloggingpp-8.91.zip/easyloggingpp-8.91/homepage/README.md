###homepage/

*This is folder contains source for [EasyLogging++ homepage](http://icplusplus.com/tools/easylogging)*
