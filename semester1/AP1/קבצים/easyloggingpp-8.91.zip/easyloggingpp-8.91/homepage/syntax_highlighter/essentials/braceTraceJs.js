<script language="javascript">
    highlightBrace = function(brace){
        document.getElementById(brace).className="Bracetrace";
    }
    normalizeBrace = function(brace){
    document.getElementById(brace).className="";
    }
</script>
