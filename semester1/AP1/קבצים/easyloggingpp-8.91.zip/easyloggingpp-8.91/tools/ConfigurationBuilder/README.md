EasyLogging++ Configuration Builder
-----------------------------------

This tool can be used to build your configuration files quickly via GUI interactions.

###### Get
You can get this tool by forking our git repository and build it yourself. Binary version will be available in future.

###### Build
Configuration Builder is built using C++/Qt 5.0.2 but has been successfully built previously using Qt 4.6.
