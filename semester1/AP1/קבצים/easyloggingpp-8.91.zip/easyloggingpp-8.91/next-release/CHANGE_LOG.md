 * 8.90:
     - All classes use fully qualified name from `internal namespace`
     - Removed unnecessary macro checks while undefining macros
     - Added `#undef`s for conditional and interval level based macros
     - Updated message when logger is not configured
