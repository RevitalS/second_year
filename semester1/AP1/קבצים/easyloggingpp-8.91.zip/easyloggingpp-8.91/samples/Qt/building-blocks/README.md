###### EasyLogging++ Samples - building-blocks

*THIS IS AN INCOMPLETE VERSION OF "squares" BOARD GAME (ENGINE AND UI).*

Check out [sample log here](https://github.com/mkhan3189/EasyLoggingPP/blob/master/samples/logs/building-blocks.log)

