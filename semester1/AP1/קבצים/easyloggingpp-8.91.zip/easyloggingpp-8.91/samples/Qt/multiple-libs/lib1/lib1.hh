#ifndef LIB1_HH
#define LIB1_HH
#include "lib1_global.hh"

class LIB1SHARED_EXPORT Lib1
{
public:
    Lib1();
};

#endif // LIB1_HH
