#include "lib2.hh"

#include "easylogging++.h"
_INITIALIZE_EASYLOGGINGPP
Lib2::Lib2()
{
    LINFO << "Lib2 initialized";
}
