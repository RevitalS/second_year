#include "lib1.hh"

#include "easylogging++.h"
_INITIALIZE_EASYLOGGINGPP

Lib1::Lib1()
{
    LINFO << "Lib1 initialized";
}
