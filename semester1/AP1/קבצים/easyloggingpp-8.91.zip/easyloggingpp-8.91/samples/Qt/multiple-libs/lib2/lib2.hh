#ifndef LIB2_HH
#define LIB2_HH

#include "lib2_global.hh"

class LIB2SHARED_EXPORT Lib2
{
public:
    Lib2();
};

#endif // LIB2_HH
