#include "easylogging++.h"

_INITIALIZE_EASYLOGGINGPP

int main(void) {
    
    LINFO << "My first ultimate log message";

    return 0;
}
