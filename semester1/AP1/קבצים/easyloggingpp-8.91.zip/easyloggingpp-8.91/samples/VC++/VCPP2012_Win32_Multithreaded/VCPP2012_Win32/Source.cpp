#include "easylogging++.h"

void ma() {
	LINFO << "test";
}