CONTRIBUTORS - EasyLogging++
============================

 * mkhan3189 <mkhan3189@gmail.com> (Main author and lead maintainer)
 * miguelishawt <miguel.martin7.5@hotmail.com> (Contributions for v3.xx)
