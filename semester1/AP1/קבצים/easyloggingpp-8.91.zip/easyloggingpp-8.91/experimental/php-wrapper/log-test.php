<?php
include_once("log-wrapper/logger.php");


logInfo("this is test from php wrapper");
logError("this is test ERROR from php wrapper");

?>
