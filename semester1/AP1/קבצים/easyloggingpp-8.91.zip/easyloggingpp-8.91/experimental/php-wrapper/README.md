###PHP Wrapper for EasyLogging++

*DO NOT USE IT - THIS IS IN VERY EARLY STAGES AND MAY NOT BE SUITABLE IN TERMS OF PERFORMANCE*


This can be done easily with some tricks presented at http://devzone.zend.com/1435/wrapping-c-classes-in-a-php-extension/
