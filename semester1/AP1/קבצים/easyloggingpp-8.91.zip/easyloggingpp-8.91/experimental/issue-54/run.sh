g++ main.cpp -o m && ./m && rm m
