/*
 * main.cpp
 *
 *  Created on: Jan 20, 2017
 *      Author: viki
 */

#include "MyTask.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

int main() {
	int counter = 0;
	pthread_mutex_t lock;

	pthread_mutex_init(&lock, NULL);

	MyTask task1(1, &counter, &lock);
	MyTask task2(2, &counter, &lock);
	MyTask task3(3, &counter, &lock);

	task1.start();
	task2.start();
	task3.start();

	//exit(0);
	//pthread_exit(NULL);

	task1.join();
	task2.join();
	task3.join();

	pthread_mutex_destroy(&lock);

	cout << "counter: " << counter << endl;
	cout << "End of main" << endl;
}


